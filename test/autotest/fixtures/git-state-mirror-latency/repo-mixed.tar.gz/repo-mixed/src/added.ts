export const ADDED = true
