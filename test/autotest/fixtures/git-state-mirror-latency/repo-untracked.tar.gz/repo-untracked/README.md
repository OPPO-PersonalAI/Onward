# repo-untracked

Fixture for the added (purple) status colour via an untracked file.
