# repo-mixed-ad

Mixed (blue): a staged add coexists with a worktree delete.
