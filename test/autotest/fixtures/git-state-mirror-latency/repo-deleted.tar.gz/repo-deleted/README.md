# repo-deleted

Fixture for the deleted (red) bucket: deletions are the only change.
