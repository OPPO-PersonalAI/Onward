# non-git-dir

Not a git repository — fixture for the unknown / no-status code path.
