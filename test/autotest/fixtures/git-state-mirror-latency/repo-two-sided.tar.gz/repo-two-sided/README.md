# repo-two-sided

Mixed (blue): ONE file is staged-modified AND worktree-deleted (XY="MD").
